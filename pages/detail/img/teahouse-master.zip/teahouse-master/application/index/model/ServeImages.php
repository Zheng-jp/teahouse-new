<?php
namespace app\index\model;

use think\Model;

class ServeImages extends Model
{

    protected $table = "tb_serve_images";

}