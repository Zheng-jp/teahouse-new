<?php
namespace app\index\model;

use think\Model;

class Shoppings extends Model
{

    protected $table = "tb_shopping";

}