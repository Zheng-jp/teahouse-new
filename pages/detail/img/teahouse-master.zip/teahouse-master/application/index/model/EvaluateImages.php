<?php
namespace app\index\model;

use think\Model;

class EvaluateImages extends Model
{

    protected $table = "tb_evaluate_images";

}