<?php
namespace app\admin\model;

use think\Model;

class Good extends Model
{
    protected $table = "tb_goods";
}