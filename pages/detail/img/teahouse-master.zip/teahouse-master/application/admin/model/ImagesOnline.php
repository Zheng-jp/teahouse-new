<?php
/**
 * Created by PhpStorm.
 * User: 李火生
 * Date: 2018/10/31
 * Time: 16:55
 */
namespace  app\admin\model;
use think\Model;

class ImagesOnline extends Model{
    protected  $table ="tb_images_online";
}