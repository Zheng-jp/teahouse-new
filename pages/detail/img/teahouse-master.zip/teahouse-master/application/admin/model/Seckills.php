<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/9/11
 * Time: 10:23
 */
namespace app\admin\model;

use think\Model;

class Seckills extends Model
{
    protected $table = "tb_seckill";
}