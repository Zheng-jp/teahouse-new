<?php
namespace app\admin\model;

use think\Model;

class goods_type extends Model{
    protected $table = "tb_goods_type";

}