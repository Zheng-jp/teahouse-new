<?php
namespace app\admin\model;

use think\Model;

class GoodsImages extends Model
{

    protected $table = "tb_goods_images";

}