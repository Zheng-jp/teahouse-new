<?php
namespace app\admin\model;

use think\Model;

class Shopping extends Model
{

    protected $table = "tb_shopping_shop";

}