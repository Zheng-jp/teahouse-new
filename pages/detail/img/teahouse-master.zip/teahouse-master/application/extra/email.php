<?php
/**
 * Created by PhpStorm.
 * User: 李火生
 * Date: 2018/8/6
 * Time: 9:54
 */

return [
    'host'=>'smtp.163.com',
    'username'=>'18777531176@163.com',
    //密钥
    'password'=>'1061525487jan'
];